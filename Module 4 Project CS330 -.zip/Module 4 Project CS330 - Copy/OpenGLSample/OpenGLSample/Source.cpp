﻿/*
Author: Mathew Denison
Date: 7/10/2022
Module 4 Milestone
*/

#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"      // Image loading Utility functions

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <camera.h> // Camera class

using namespace std; // Standard namespace


/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Tutorial 4.3"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;
   
    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao[12];         // Handle for the vertex array object
        GLuint vbo[12];         // Handle for the vertex buffer object
        GLuint nVertices[12];    // Number of indices of the mesh
    };

    enum {
        PERSPECTIVE_DISPLAY,
        ORTHOGRAPHIC_DISPLAY
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    GLMesh gMesh;

    // Texture id
    GLuint gTextureIdPencilTip;
    GLuint gTextureIdPencilBody;
    GLuint gTextureIdPencilEraser;
    GLuint gTextureIdTableTop;
    GLuint gTextureIdKeyboard;
    GLuint gTextureIdPhone;
    GLuint gTextureIdScreen;
    GLuint gTextureIdPhoneEdge;
    GLuint gTextureIdScreenEdge;
    GLuint gTextureIdSecondLight;
    // Shader program
    GLuint gPencilProgramId;
    glm::vec2 gUVScale(0.1f, 0.1f);
    GLuint gLampProgramId;

    // camera
    Camera gCamera(glm::vec3(0.0f, 0.0f, 3.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;
    int perspective = ORTHOGRAPHIC_DISPLAY;
    bool keypressed;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    // Subject position and scale
    glm::vec3 gPencilPosition(-3.0f, -3.0f, -3.0f);
    glm::vec3 gPencilScale(1.0f);

    //Pyramid and light color
    glm::vec3 gObjectColor(1.0f, 0.2f, 0.0f);
    glm::vec3 gLightColor(1.0f, 1.0f, 1.0f);

    //Light position and scale
    glm::vec3 gLightPosition(1.5f, 2.5f, 3.0f);
    glm::vec3 gLightScale(0.3f);
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


const GLchar* pencilVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
    layout(location = 1) in vec3 normal; // VAP position 1 for normals
    layout(location = 2) in vec2 textureCoordinate;

    out vec3 vertexNormal; // For outgoing normals to fragment shader
    out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
    out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
);


/* Cube Fragment Shader Source Code*/
const GLchar* pencilFragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 1.0f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 0.8f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

        //Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);

/* Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

    out vec4 fragmentColorLight; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
    fragmentColorLight = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);

void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader program
    if (!UCreateShaderProgram(pencilVertexShaderSource, pencilFragmentShaderSource, gPencilProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
        return EXIT_FAILURE;

    // Load texture
    const char* pencilTiptexFilename = "PencilTip.PNG";
    const char* pencilBodytexFilename = "Pencil Body.PNG";
    const char* pencilErasertexFilename = "Pencil Eraser.PNG";
    const char* tableToptexFilename = "Table.PNG";
    const char* keyboardtexFilename = "Screen.PNG";
    const char* phonetexFilename = "phone.PNG";
    const char* screentexFilename = "Screen.PNG";
    const char* phoneEdgetexFilename = "Screen.PNG";
    const char* screenEdgetexFilename = "Phone Edge.PNG";
    
    if (!UCreateTexture(pencilTiptexFilename, gTextureIdPencilTip))
    {
        cout << "Failed to load texture " << pencilTiptexFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(pencilBodytexFilename, gTextureIdPencilBody))
    {
        cout << "Failed to load texture " << pencilBodytexFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(pencilErasertexFilename, gTextureIdPencilEraser))
    {
        cout << "Failed to load texture " << pencilErasertexFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(tableToptexFilename, gTextureIdTableTop))
    {
        cout << "Failed to load texture " << tableToptexFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(keyboardtexFilename, gTextureIdKeyboard))
    {
        cout << "Failed to load texture " << keyboardtexFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(phonetexFilename, gTextureIdPhone))
    {
        cout << "Failed to load texture " << phonetexFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(screentexFilename, gTextureIdScreen))
    {
        cout << "Failed to load texture " << screentexFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(phoneEdgetexFilename, gTextureIdPhoneEdge))
    {
        cout << "Failed to load texture " << phoneEdgetexFilename << endl;
        return EXIT_FAILURE;
    }
    if (!UCreateTexture(screenEdgetexFilename, gTextureIdScreenEdge))
    {
        cout << "Failed to load texture " << screenEdgetexFilename << endl;
        return EXIT_FAILURE;
    }
    
    
    // tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
    glUseProgram(gPencilProgramId);
    // We set the texture as texture unit 0
    glUniform1i(glGetUniformLocation(gPencilProgramId, "uTexture"), 0);

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMesh);

    // Release texture
    UDestroyTexture(gTextureIdPencilTip);
    UDestroyTexture(gTextureIdPencilBody);
    UDestroyTexture(gTextureIdPencilEraser);
    UDestroyTexture(gTextureIdTableTop);
    UDestroyTexture(gTextureIdKeyboard);
    UDestroyTexture(gTextureIdPhone);
    UDestroyTexture(gTextureIdScreen);
    UDestroyTexture(gTextureIdPhoneEdge);
    UDestroyTexture(gTextureIdScreenEdge);
    UDestroyTexture(gTextureIdSecondLight);
    

    // Release shader program
    UDestroyShaderProgram(gPencilProgramId);
    UDestroyShaderProgram(gLampProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to capture our mouse
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
        keypressed = true;
    }
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_RELEASE) {
        if (keypressed) {
            keypressed = false;
            // Change to the opposite of the current display type
            if (perspective == ORTHOGRAPHIC_DISPLAY) {
                perspective = PERSPECTIVE_DISPLAY;
            }
            else {
                perspective = ORTHOGRAPHIC_DISPLAY;
            }
        }
    }
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}



    void URender()
    {
        // Enable z-depth
        glEnable(GL_DEPTH_TEST);

        // Clear the frame and z buffers
        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // camera/view transformation
        glm::mat4 view = gCamera.GetViewMatrix();


        glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        switch (perspective) {
        case PERSPECTIVE_DISPLAY:
            projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.01f, 100.0f);
            break;
        case ORTHOGRAPHIC_DISPLAY:
            //calculate current position from perspective
            float pos = glm::radians(gCamera.Zoom) / 2.0f * 3.1415926f / 180.0f;
            float pos2 = sqrt(gCamera.Position.x * gCamera.Position.x + gCamera.Position.y * gCamera.Position.y);
            //focus is the distance from the camera
            float focus = sqrt(pos2 * pos2 + gCamera.Position.z * gCamera.Position.z);
            float top = focus / 2;
            float right = top * (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT;
            projection = glm::ortho(-right, right, -top, top, 0.01f, 100.0f);
            break;
        }

#pragma region pencilTip
        glm::mat4 projection1 = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMesh.vao[0]);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(gPencilProgramId);

        // 1. Scales the object by 2
        glm::mat4 scale = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
        // 2. Rotates shape by 15 degrees in the x axis
        glm::mat4 rotation = glm::rotate(3.141592f, glm::vec3(-4.0f, -0.0f, 5.0f));
        // 3. Place object at the origin
        glm::mat4 translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model = glm::translate(gPencilPosition) * glm::scale(gPencilScale);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc1 = glGetUniformLocation(gPencilProgramId, "model");
        GLint viewLoc1 = glGetUniformLocation(gPencilProgramId, "view");
        GLint projLoc1 = glGetUniformLocation(gPencilProgramId, "projection");

        glUniformMatrix4fv(modelLoc1, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc1, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc1, 1, GL_FALSE, glm::value_ptr(projection));



        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc = glGetUniformLocation(gPencilProgramId, "objectColor");
        GLint lightColorLoc = glGetUniformLocation(gPencilProgramId, "lightColor");
        GLint lightPositionLoc = glGetUniformLocation(gPencilProgramId, "lightPos");
        GLint viewPositionLoc = glGetUniformLocation(gPencilProgramId, "viewPosition");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(lightPositionLoc, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        const glm::vec3 cameraPosition = gCamera.Position;
        glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc = glGetUniformLocation(gPencilProgramId, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdPencilTip);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[0]);
#pragma endregion

#pragma region pencilBody
        glm::mat4 projection2 = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMesh.vao[1]);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(gPencilProgramId);

        // 1. Scales the object by 2
        glm::mat4 scale1 = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
        // 2. Rotates shape by 15 degrees in the x axis
        glm::mat4 rotation1 = glm::rotate(3.141592f, glm::vec3(-4.0f, -0.0f, 5.0f));
        // 3. Place object at the origin
        glm::mat4 translation1 = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model1 = glm::translate(gPencilPosition) * glm::scale(gPencilScale);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc = glGetUniformLocation(gPencilProgramId, "model");
        GLint viewLoc = glGetUniformLocation(gPencilProgramId, "view");
        GLint projLoc = glGetUniformLocation(gPencilProgramId, "projection");

        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));



        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc1 = glGetUniformLocation(gPencilProgramId, "objectColor");
        GLint lightColorLoc1 = glGetUniformLocation(gPencilProgramId, "lightColor");
        GLint lightPositionLoc1 = glGetUniformLocation(gPencilProgramId, "lightPos");
        GLint viewPositionLoc1 = glGetUniformLocation(gPencilProgramId, "viewPosition");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform3f(objectColorLoc1, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc1, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(lightPositionLoc1, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        const glm::vec3 cameraPosition1 = gCamera.Position;
        glUniform3f(viewPositionLoc1, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc1 = glGetUniformLocation(gPencilProgramId, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdPencilBody);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[1]);
#pragma endregion

#pragma region pencilEraser
        glm::mat4 projection3 = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMesh.vao[2]);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(gPencilProgramId);

        // 1. Scales the object by 2
        glm::mat4 scale2 = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
        // 2. Rotates shape by 15 degrees in the x axis
        glm::mat4 rotation2 = glm::rotate(3.141592f, glm::vec3(-4.0f, -0.0f, 5.0f));
        // 3. Place object at the origin
        glm::mat4 translation2 = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model2 = glm::translate(gPencilPosition) * glm::scale(gPencilScale);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc2 = glGetUniformLocation(gPencilProgramId, "model");
        GLint viewLoc2 = glGetUniformLocation(gPencilProgramId, "view");
        GLint projLoc2 = glGetUniformLocation(gPencilProgramId, "projection");

        glUniformMatrix4fv(modelLoc2, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc2, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc2, 1, GL_FALSE, glm::value_ptr(projection));



        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc2 = glGetUniformLocation(gPencilProgramId, "objectColor");
        GLint lightColorLoc2 = glGetUniformLocation(gPencilProgramId, "lightColor");
        GLint lightPositionLoc2 = glGetUniformLocation(gPencilProgramId, "lightPos");
        GLint viewPositionLoc2 = glGetUniformLocation(gPencilProgramId, "viewPosition");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform3f(objectColorLoc2, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc2, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(lightPositionLoc2, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        const glm::vec3 cameraPosition2 = gCamera.Position;
        glUniform3f(viewPositionLoc2, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc2 = glGetUniformLocation(gPencilProgramId, "uvScale");
        glUniform2fv(UVScaleLoc2, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdPencilEraser);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[2]);
#pragma endregion

#pragma region tableTop
        glm::mat4 projection4 = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMesh.vao[3]);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(gPencilProgramId);

        // 1. Scales the object by 2
        glm::mat4 scale3 = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
        // 2. Rotates shape by 15 degrees in the x axis
        glm::mat4 rotation3 = glm::rotate(3.141592f, glm::vec3(-4.0f, -0.0f, 5.0f));
        // 3. Place object at the origin
        glm::mat4 translation3 = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model3 = glm::translate(gPencilPosition) * glm::scale(gPencilScale);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc3 = glGetUniformLocation(gPencilProgramId, "model");
        GLint viewLoc3 = glGetUniformLocation(gPencilProgramId, "view");
        GLint projLoc3 = glGetUniformLocation(gPencilProgramId, "projection");

        glUniformMatrix4fv(modelLoc3, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc3, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc3, 1, GL_FALSE, glm::value_ptr(projection));



        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc3 = glGetUniformLocation(gPencilProgramId, "objectColor");
        GLint lightColorLoc3 = glGetUniformLocation(gPencilProgramId, "lightColor");
        GLint lightPositionLoc3 = glGetUniformLocation(gPencilProgramId, "lightPos");
        GLint viewPositionLoc3 = glGetUniformLocation(gPencilProgramId, "viewPosition");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform3f(objectColorLoc3, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc3, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(lightPositionLoc3, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        const glm::vec3 cameraPosition3 = gCamera.Position;
        glUniform3f(viewPositionLoc3, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc3 = glGetUniformLocation(gPencilProgramId, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdTableTop);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[3]);
#pragma endregion

#pragma region keyboard
        glm::mat4 projection5 = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMesh.vao[4]);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(gPencilProgramId);

        // 1. Scales the object by 2
        glm::mat4 scale4 = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
        // 2. Rotates shape by 15 degrees in the x axis
        glm::mat4 rotation4 = glm::rotate(3.141592f, glm::vec3(-4.0f, -0.0f, 5.0f));
        // 3. Place object at the origin
        glm::mat4 translation4 = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model4 = glm::translate(gPencilPosition) * glm::scale(gPencilScale);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc4 = glGetUniformLocation(gPencilProgramId, "model");
        GLint viewLoc4 = glGetUniformLocation(gPencilProgramId, "view");
        GLint projLoc4 = glGetUniformLocation(gPencilProgramId, "projection");

        glUniformMatrix4fv(modelLoc4, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc4, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc4, 1, GL_FALSE, glm::value_ptr(projection));



        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc4 = glGetUniformLocation(gPencilProgramId, "objectColor");
        GLint lightColorLoc4 = glGetUniformLocation(gPencilProgramId, "lightColor");
        GLint lightPositionLoc4 = glGetUniformLocation(gPencilProgramId, "lightPos");
        GLint viewPositionLoc4 = glGetUniformLocation(gPencilProgramId, "viewPosition");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform3f(objectColorLoc4, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc4, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(lightPositionLoc4, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        const glm::vec3 cameraPosition4 = gCamera.Position;
        glUniform3f(viewPositionLoc4, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc4 = glGetUniformLocation(gPencilProgramId, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdKeyboard);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[4]);
#pragma endregion

#pragma region phone
        glm::mat4 projection6 = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMesh.vao[5]);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(gPencilProgramId);

        // 1. Scales the object by 2
        glm::mat4 scale5 = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
        // 2. Rotates shape by 15 degrees in the x axis
        glm::mat4 rotation5 = glm::rotate(3.141592f, glm::vec3(-4.0f, -0.0f, 5.0f));
        // 3. Place object at the origin
        glm::mat4 translation5 = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model5 = glm::translate(gPencilPosition) * glm::scale(gPencilScale);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc5 = glGetUniformLocation(gPencilProgramId, "model");
        GLint viewLoc5 = glGetUniformLocation(gPencilProgramId, "view");
        GLint projLoc5 = glGetUniformLocation(gPencilProgramId, "projection");

        glUniformMatrix4fv(modelLoc5, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc5, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc5, 1, GL_FALSE, glm::value_ptr(projection));



        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc5 = glGetUniformLocation(gPencilProgramId, "objectColor");
        GLint lightColorLoc5 = glGetUniformLocation(gPencilProgramId, "lightColor");
        GLint lightPositionLoc5 = glGetUniformLocation(gPencilProgramId, "lightPos");
        GLint viewPositionLoc5 = glGetUniformLocation(gPencilProgramId, "viewPosition");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform3f(objectColorLoc5, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc5, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(lightPositionLoc5, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        const glm::vec3 cameraPosition5 = gCamera.Position;
        glUniform3f(viewPositionLoc5, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc5 = glGetUniformLocation(gPencilProgramId, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdPhone);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[5]);
#pragma endregion

#pragma region screen
        glm::mat4 projection7 = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMesh.vao[6]);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(gPencilProgramId);

        // 1. Scales the object by 2
        glm::mat4 scale6 = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
        // 2. Rotates shape by 15 degrees in the x axis
        glm::mat4 rotation6 = glm::rotate(3.141592f, glm::vec3(-4.0f, -0.0f, 5.0f));
        // 3. Place object at the origin
        glm::mat4 translation6 = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model6 = glm::translate(gPencilPosition) * glm::scale(gPencilScale);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc6 = glGetUniformLocation(gPencilProgramId, "model");
        GLint viewLoc6 = glGetUniformLocation(gPencilProgramId, "view");
        GLint projLoc6 = glGetUniformLocation(gPencilProgramId, "projection");

        glUniformMatrix4fv(modelLoc6, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc6, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc6, 1, GL_FALSE, glm::value_ptr(projection));



        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc6 = glGetUniformLocation(gPencilProgramId, "objectColor");
        GLint lightColorLoc6 = glGetUniformLocation(gPencilProgramId, "lightColor");
        GLint lightPositionLoc6 = glGetUniformLocation(gPencilProgramId, "lightPos");
        GLint viewPositionLoc6 = glGetUniformLocation(gPencilProgramId, "viewPosition");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform3f(objectColorLoc6, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc6, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(lightPositionLoc6, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        const glm::vec3 cameraPosition6 = gCamera.Position;
        glUniform3f(viewPositionLoc6, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc6 = glGetUniformLocation(gPencilProgramId, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdScreen);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[6]);
#pragma endregion

#pragma region phoneEdge
        glm::mat4 projection8 = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMesh.vao[7]);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(gPencilProgramId);

        // 1. Scales the object by 2
        glm::mat4 scale7 = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
        // 2. Rotates shape by 15 degrees in the x axis
        glm::mat4 rotation7 = glm::rotate(3.141592f, glm::vec3(-4.0f, -0.0f, 5.0f));
        // 3. Place object at the origin
        glm::mat4 translation7 = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model7 = glm::translate(gPencilPosition) * glm::scale(gPencilScale);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc7 = glGetUniformLocation(gPencilProgramId, "model");
        GLint viewLoc7 = glGetUniformLocation(gPencilProgramId, "view");
        GLint projLoc7 = glGetUniformLocation(gPencilProgramId, "projection");

        glUniformMatrix4fv(modelLoc7, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc7, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc7, 1, GL_FALSE, glm::value_ptr(projection));



        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc7 = glGetUniformLocation(gPencilProgramId, "objectColor");
        GLint lightColorLoc7 = glGetUniformLocation(gPencilProgramId, "lightColor");
        GLint lightPositionLoc7 = glGetUniformLocation(gPencilProgramId, "lightPos");
        GLint viewPositionLoc7 = glGetUniformLocation(gPencilProgramId, "viewPosition");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform3f(objectColorLoc7, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc7, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(lightPositionLoc7, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        const glm::vec3 cameraPosition7 = gCamera.Position;
        glUniform3f(viewPositionLoc7, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc7 = glGetUniformLocation(gPencilProgramId, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdPhoneEdge);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[7]);
#pragma endregion

#pragma region screenEdge
        glm::mat4 projection9 = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMesh.vao[8]);

        // CUBE: draw cube
        //----------------
        // Set the shader to be used
        glUseProgram(gPencilProgramId);

        // 1. Scales the object by 2
        glm::mat4 scale8 = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
        // 2. Rotates shape by 15 degrees in the x axis
        glm::mat4 rotation8 = glm::rotate(3.141592f, glm::vec3(-4.0f, -0.0f, 5.0f));
        // 3. Place object at the origin
        glm::mat4 translation8 = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
        // Model matrix: transformations are applied right-to-left order
        glm::mat4 model8 = glm::translate(gPencilPosition) * glm::scale(gPencilScale);

        // Retrieves and passes transform matrices to the Shader program
        GLint modelLoc8 = glGetUniformLocation(gPencilProgramId, "model");
        GLint viewLoc8 = glGetUniformLocation(gPencilProgramId, "view");
        GLint projLoc8 = glGetUniformLocation(gPencilProgramId, "projection");

        glUniformMatrix4fv(modelLoc8, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc8, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc8, 1, GL_FALSE, glm::value_ptr(projection));



        // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
        GLint objectColorLoc8 = glGetUniformLocation(gPencilProgramId, "objectColor");
        GLint lightColorLoc8 = glGetUniformLocation(gPencilProgramId, "lightColor");
        GLint lightPositionLoc8 = glGetUniformLocation(gPencilProgramId, "lightPos");
        GLint viewPositionLoc8 = glGetUniformLocation(gPencilProgramId, "viewPosition");

        // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
        glUniform3f(objectColorLoc8, gObjectColor.r, gObjectColor.g, gObjectColor.b);
        glUniform3f(lightColorLoc8, gLightColor.r, gLightColor.g, gLightColor.b);
        glUniform3f(lightPositionLoc8, gLightPosition.x, gLightPosition.y, gLightPosition.z);
        const glm::vec3 cameraPosition8 = gCamera.Position;
        glUniform3f(viewPositionLoc8, cameraPosition.x, cameraPosition.y, cameraPosition.z);

        GLint UVScaleLoc8 = glGetUniformLocation(gPencilProgramId, "uvScale");
        glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale));

        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, gTextureIdScreenEdge);

        // Draws the triangles
        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[8]);
#pragma endregion

        
        // Activate the cube VAO (used by cube and lamp)
        glBindVertexArray(gMesh.vao[1]);

        // LAMP: draw lamp
       //----------------
        glUseProgram(gLampProgramId);

        // 1. Scales the object by 2
        glm::mat4 scale10 = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
        // 2. Rotates shape by 15 degrees in the x axis
        glm::mat4 rotation10 = glm::rotate(3.141592f, glm::vec3(-4.0f, -0.0f, 5.0f));
        // 3. Place object at the origin
        glm::mat4 translation10 = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));
        //Transform the smaller cube used as a visual que for the light source
        model = glm::translate(gLightPosition) * glm::scale(gLightScale);

        // Reference matrix uniforms from the Lamp Shader program
        modelLoc = glGetUniformLocation(gLampProgramId, "model");
        viewLoc = glGetUniformLocation(gLampProgramId, "view");
        projLoc = glGetUniformLocation(gLampProgramId, "projection");

        // Pass matrix data to the Lamp Shader program's matrix uniforms
        glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

        glDrawArrays(GL_TRIANGLES, 0, gMesh.nVertices[0]);
        // Deactivate the Vertex Array Object
        glBindVertexArray(0);
        glUseProgram(0);

        // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
        glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
    }

// UCreateMesh to create triangles used for drawing
void UCreateMesh(GLMesh& mesh)
{
    // Position and Color data
    GLfloat pencilTipVerts[] = {
        // Pencil Tip
        0.5f,  0.5f, 0.0f,            0.0f, 0.0f,                 0.0f, -1.0f,  0.0f,// Vertex 0 Top Right Cyan
        0.5f, -0.5f, 0.0f,            1.0f, 0.0f,                 0.0f, -1.0f,  0.0f,// Vertex 1 Bottom Right Blue
        -0.5f, -0.5f, 0.0f,           0.0f, 1.0f,                0.0f, -1.0f,  0.0f, // Vertex 2 Bottom Left Yellow

         0.5f,  0.5f, 0.0f,            0.0f, 0.0f,                    0.0f, -1.0f,  0.0f,// Vertex 0 Top Right Cyan
        -0.5f,  0.5f, 0.0f,            1.0f, 0.0f,                    0.0f, -1.0f,  0.0f,// Vertex 3 Top Left Pink
        -0.5f, -0.5f, 0.0f,            0.0f, 1.0f,                    0.0f, -1.0f,  0.0f,// Vertex 2 Bottom Left Yellow

        0.5f,  0.5f, 0.0f,             0.0f, 0.0f,                     -0.8f, 0.5f,  0.0f, // Vertex 0 Top Right Cyan
        0.5f, -0.5f, 0.0f,             1.0f, 0.0f,                     -0.8f, 0.5f,  0.0f,// Vertex 1 Bottom Right Blue
        0.0f,  0.0f, 1.0f,             0.0f, 1.0f,                     -0.8f, 0.5f,  0.0f,// Vertex 4 Pyramid top White

        0.5f, -0.5f, 0.0f,             0.0f, 0.0f,                     0.0, 0.5f,  -0.8f,// Vertex 1 Bottom Right Blue
        -0.5f, -0.5f, 0.0f,            1.0f, 0.0f,                    0.0, 0.5f,  -0.8f,// Vertex 2 Bottom Left Yellow
        0.0f,  0.0f, 1.0f,             0.0f, 1.0f,                     0.0, 0.5f,  -0.8f,// Vertex 4 Pyramid top White

        -0.5f, -0.5f, 0.0f,            0.0f, 0.0f,                    0.8f, 0.5f,  0.0f,// Vertex 2 Bottom Left Yellow
        -0.5f,  0.5f, 0.0f,            1.0f, 0.0f,                    0.8f, 0.5f,  0.0f,// Vertex 3 Top Left Pink
        0.0f,  0.0f, 1.0f,             0.0f, 1.0f,                     0.8f, 0.5f,  0.0f,// Vertex 4 Pyramid top White

        -0.5f,  0.5f, 0.0f,            0.0f, 0.0f,                    0.0f, 0.5f,  0.8f,// Vertex 3 Top Left Pink
         0.5f,  0.5f, 0.0f,            1.0f, 0.0f,                    0.0f, 0.5f,  0.8f,// Vertex 0 Top Right Cyan
         0.0f,  0.0f, 1.0f,            0.0f, 1.0f,                    0.0f, 0.5f,  0.8f,// Vertex 4 Pyramid top White
    };

    GLfloat pencilBodyVerts[] = {

         -0.5f, -0.5f, 0.0f,          1.0f, 0.0f,                    0.0f, -1.0f,  0.0f,// Vertex 2 Bottom Left Yellow
        -0.5f, -0.5f, -6.0f,          0.0f, 1.0f,                     0.0f, -1.0f,  0.0f,//Vertex 5 yellow body
        0.5f, -0.5f, 0.0f,            0.0f, 0.0f,                    0.0f, -1.0f,  0.0f,// Vertex 1 Bottom Right Blue

        -0.5f, -0.5f, -6.0f,          1.0f, 0.0f,                    0.0f, -1.0f,  0.0f,//Vertex 5 yellow body
         0.5f, -0.5f, -6.0f,          0.0f, 1.0f,                    0.0f, -1.0f,  0.0f,// Vertex 6 Blue body
         0.5f, -0.5f, 0.0f,           0.0f, 0.0f,                     0.0f, -1.0f,  0.0f,// Vertex 1 Bottom Right Blue

         -0.5f, -0.5f, -6.0f,         1.0f, 0.0f,                   0.0f, -1.0f,  0.0f, //Vertex 5 yellow body
         -0.5f, -0.5f, 0.0f,          0.0f, 1.0f,                    0.0f, -1.0f,  0.0f,// Vertex 2 Bottom Left Yellow
         -0.5f,  0.5f, 0.0f,          0.0f, 0.0f,                    0.0f, -1.0f,  0.0f,// Vertex 3 Top Left Pink

         -0.5f,  0.5f, 0.0f,          1.0f, 0.0f,                    0.0f, -1.0f,  0.0f, // Vertex 3 Top Left Pink
         -0.5f,  0.5f, -6.0f,         0.0f, 1.0f,                    0.0f, -1.0f,  0.0f,// Vertex 7 Pink body
         -0.5f, -0.5f, -6.0f,         0.0f, 0.0f,                   0.0f,-1.0f,  0.0f, //Vertex 5 yellow body

         -0.5f,  0.5f, 0.0f,         1.0f, 0.0f,                    -0.8f,  0.5f,  0.0f,// Vertex 3 Top Left Pink
         -0.5f,  0.5f, -6.0f,        0.0f, 1.0f,                    -0.8f, 0.5f,  0.0f,// Vertex 7 Pink body
         0.5f,  0.5f, -6.0f,         0.0f, 0.0f,                    -0.8f, 0.5f,  0.0f,// Vertex 8 Cyan body

         -0.5f,  0.5f, 0.0f,         1.0f, 0.0f,                    -0.8f, 0.5f,  0.0f, // Vertex 3 Top Left Pink
         0.5f,  0.5f, 0.0f,          0.0f, 1.0f,                     -0.8f, 0.5f,  0.0f,// Vertex 0 Top Right Cyan
         0.5f,  0.5f, -6.0f,         0.0f, 0.0f,                    -0.8f, 0.5f,  0.0f,// Vertex 8 Cyan body

         0.5f,  0.5f, 0.0f,          1.0f, 0.0f,                     0.0, 0.5f,  -0.8f,// Vertex 0 Top Right Cyan
         0.5f,  0.5f, -6.0f,         0.0f, 1.0f,                    0.0, 0.5f,  -0.8f,// Vertex 8 Cyan body
         0.5f, -0.5f, -6.0f,         0.0f, 0.0f,                    0.0, 0.5f,  -0.8f,// Vertex 6 Blue body

         0.5f,  0.5f, 0.0f,          1.0f, 0.0f,                     0.0, 0.5f,  -0.8f,// Vertex 0 Top Right Cyan
         0.5f, -0.5f, 0.0f,          0.0f, 1.0f,                     0.0, 0.5f,  -0.8f,// Vertex 1 Bottom Right Blue
         0.5f, -0.5f, -6.0f,         0.0f, 0.0f,                    0.0, 0.5f,  -0.8f,// Vertex 6 Blue body

         -0.5f,  0.5f, -6.0f,        1.0f, 0.0f,                    0.8f, 0.5f,  0.0f,// Vertex 7 Pink body
         0.5f, -0.5f, -6.0f,         0.0f, 1.0f,                    0.8f, 0.5f,  0.0f, // Vertex 6 Blue body
         -0.5f, -.5f, -6.0f,         0.0f, 0.0f,                    0.8f, 0.5f,  0.0f, //Vertex 5 yellow body

         -0.5f,  0.5f, -6.0f,        1.0f, 0.0f,                    0.8f, 0.5f,  0.0f, // Vertex 7 Pink body
         0.5f, -0.5f, -6.0f,         0.0f, 1.0f,                    0.8f, 0.5f,  0.0f,// Vertex 6 Blue body
         0.5f,  0.5f, -6.0f,         0.0f, 0.0f,                    0.8f, 0.5f,  0.0f,// Vertex 8 Cyan body
    };

    GLfloat pencilEraserVerts[] = {
         -0.5f, -.5f, -6.0f,        1.0f, 0.0f,                   0.0f, 0.5f,  0.8f,//Vertex 5 yellow body
         -0.5f, -.5f, -7.0f,        0.0f, 1.0f,                   0.0f, 0.5f,  0.8f,//Vertex 9 yellow body
         0.5f, -0.5f, -7.0f,        0.0f, 0.0f,                   0.0f, 0.5f,  0.8f,// Vertex 10 Blue body

         -0.5f, -.5f, -6.0f,        1.0f, 0.0f,                   0.0f, 0.5f,  0.8f,//Vertex 5 yellow body
         0.5f, -0.5f, -6.0f,        0.0f, 1.0f,                   0.0f, 0.5f,  0.8f,// Vertex 6 Blue body
         0.5f, -0.5f, -7.0f,        0.0f, 0.0f,                   0.0f, 0.5f,  0.8f,// Vertex 10 Blue body

         -0.5f, -.5f, -6.0f,        1.0f, 0.0f,                   0.0f, 0.5f,  0.8f,//Vertex 5 yellow body
         -0.5f, -.5f, -7.0f,        0.0f, 1.0f,                   0.0f, 0.5f,  0.8f,//Vertex 9 yellow body
         -0.5f,  0.5f, -7.0f,       0.0f, 0.0f,                  0.0f, 0.5f,  0.8f,// Vertex 11 Pink body

         -0.5f,  0.5f, -7.0f,       1.0f, 0.0f,                  0.0f, 0.5f,  0.8f,// Vertex 11 Pink body
         -0.5f,  0.5f, -6.0f,       0.0f, 1.0f,                   0.0f, 0.5f,  0.8f,// Vertex 7 Pink body
         -0.5f, -.5f, -6.0f,        0.0f, 0.0f,                   0.0f, 0.5f,  0.8f,//Vertex 5 yellow body

         0.5f,  0.5f, -6.0f,        1.0f, 0.0f,                   0.0f, 0.5f,  0.8f,// Vertex 8 Cyan body
         -0.5f,  0.5f, -6.0f,       0.0f, 1.0f,                   0.0f, 0.5f,  0.8f,// Vertex 7 Pink body
         -0.5f,  0.5f, -7.0f,       0.0f, 0.0f,                  0.0f, 0.5f,  0.8f,// Vertex 11 Pink body
         

         -0.5f,  0.5f, -7.0f,       1.0f, 0.0f,                  0.0f, 0.5f,  0.8f,// Vertex 11 Pink body
         0.5f,  0.5f, -7.0f,        0.0f, 1.0f,                   0.0f, 0.5f,  0.8f,
         0.5f,  0.5f, -6.0f,       1.0f, 0.0f,                   0.0f, 0.5f,  0.8f,// Vertex 7 Pink body

         0.5f, -0.5f, -6.0f,        1.0f, 0.0f,                   0.0f, 0.5f,  0.8f,// Vertex 6 Blue body
         0.5f, -0.5f, -7.0f,        0.0f, 1.0f,                   0.0f, 0.5f,  0.8f,// Vertex 10 Blue body
         0.5f,  0.5f, -6.0f,        0.0f, 0.0f,                   0.0f, 0.5f,  0.8f,// Vertex 8 Cyan body

         0.5f,  0.5f, -6.0f,        1.0f, 0.0f,                    0.0f, 0.5f,  0.8f,// Vertex 8 Cyan body
         0.5f,  0.5f, -7.0f,        0.0f, 1.0f,                    0.0f, 0.5f,  0.8f,// Vertex 12 Cyan body
         0.5f, -0.5f, -7.0f,        0.0f, 0.0f,                    0.0f, 0.5f,  0.8f,// Vertex 10 Blue body
    };

    GLfloat tableTopVerts[] = {
         -16.0f, -0.5f, 30.0f,       1.0f, 0.0f,                  0.0f, -1.0f,  0.0f,
         16.0f,  -0.5f, 30.0f,       0.0f, 1.0f,                  0.0f, -1.0f,  0.0f,
         -16.0f, -0.5f, -30.0f,      0.0f, 0.0f,                  0.0f, -1.0f,  0.0f,
          
         16.0f, -0.5f, 30.0f,        1.0f, 0.0f,                  0.0f, -1.0f,  0.0f,
         -16.0f, -0.5f, -30.0f,      0.0f, 1.0f,                  0.0f, -1.0f,  0.0f,
         16.0f, -0.5f, -30.0f,       0.0f, 0.0f,                  0.0f, -1.0f,  0.0f,
    };

    GLfloat keyboardVerts[] = {

        //bottom
        4.0f, -0.5f, -2.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        8.0f, -0.5f, -2.5f,         0.0f, 1.0f,                  0.0f, -1.0f, 0.0f, //2
        4.0f, -0.5f, -15.0f,        0.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        4.0f, -0.5f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        8.0f, -0.5f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        8.0f, -0.5f, -2.5f,         1.0f, 0.0f,                   0.0f, -1.0f, 0.0f, //2

        //top
        4.0f,  -0.3f, -2.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        8.0f,  -0.3f, -2.5f,         0.0f, 1.0f,                  0.0f, -1.0f, 0.0f, //6
        4.0f,  -0.3f, -15.0f,        0.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7

        4.0f,  -0.3f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7
        8.0f,  -0.3f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8
        8.0f,  -0.3f, -2.5f,         1.0f, 0.0f,                   0.0f, -1.0f, 0.0f, //6

        //left edge
        4.0f, -0.5f, -2.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        4.0f,  -0.3f, -2.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        8.0f, -0.5f, -2.5f,         0.0f, 1.0f,                  0.0f, -1.0f, 0.0f, //2

        8.0f, -0.5f, -2.5f,         0.0f, 1.0f,                  0.0f, -1.0f, 0.0f, //2
        8.0f,  -0.3f, -2.5f,         0.0f, 1.0f,                  0.0f, -1.0f, 0.0f, //6
        4.0f,  -0.3f, -2.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5

        //back edge
        4.0f, -0.5f, -2.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        4.0f,  -0.3f, -2.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        4.0f, -0.5f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        4.0f, -0.5f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        4.0f,  -0.3f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7
        4.0f,  -0.3f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5

        //right edge
        4.0f, -0.5f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        4.0f,  -0.3f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7
        8.0f, -0.5f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4

        8.0f, -0.5f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        8.0f,  -0.3f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8
        4.0f,  -0.3f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7

        //front edge
        8.0f, -0.5f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        8.0f,  -0.3f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8
        8.0f, -0.5f, -2.5f,         0.0f, 1.0f,                  0.0f, -1.0f, 0.0f, //2

        8.0f, -0.5f, -2.5f,         0.0f, 1.0f,                  0.0f, -1.0f, 0.0f, //2
        8.0f,  -0.3f, -2.5f,         0.0f, 1.0f,                  0.0f, -1.0f, 0.0f, //6
        8.0f,  -0.3f, -15.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8


    };

    GLfloat phoneVerts[] = {

        //bottom
        4.0f, -0.5f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        -4.0f, -0.5f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        -4.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        4.0f, -0.5f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        -4.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        4.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
       
        //top
        4.0f, -0.3f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        -4.0f, -0.3f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //6
        -4.0f, -0.3f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7

        4.0f, -0.3f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        -4.0f, -0.3f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7
        4.0f, -0.3f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8

    };

    GLfloat screenVerts[] = {

        //back
        -10.0f, 1.0f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        -10.0f, 9.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        -10.0f, 9.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        -10.0f, 1.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        -10.0f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        -10.0f, 9.0f, -7.0f,         1.0f, 0.0f,                   0.0f, -1.0f, 0.0f, //3


        //front
        -9.5f, 1.0f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        -9.5f, 9.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //6
        -9.5f, 9.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7

        -9.5f, 1.0f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        -9.5f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8
        -9.5f, 9.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7

        
    };

    GLfloat phoneEdgeVerts[] = {
        //left edge
        4.0f, -0.5f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        4.0f, -0.3f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        -4.0f, -0.5f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2

        -4.0f, -0.5f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        -4.0f, -0.3f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //6
        4.0f, -0.3f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5

        //back edge
        -4.0f, -0.5f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        -4.0f, -0.3f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //6
        -4.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        -4.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        -4.0f, -0.3f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //6
        -4.0f, -0.3f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7

        //right edge
        -4.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        -4.0f, -0.3f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7
        4.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4

        4.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        4.0f, -0.3f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8
        -4.0f, -0.3f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7

        //front edge
        4.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        4.0f, -0.3f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8
        4.0f, -0.5f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        4.0f, -0.5f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        4.0f, -0.3f, -18.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        4.0f, -0.3f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8

        
    };

    GLfloat screenEdgeVerts[] = {

        //right edge
         -10.0f, 1.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
         -9.5f, 1.0f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
         -10.0f, 9.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2

         -10.0f, 9.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
         -9.5f, 9.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //6
         -9.5f, 1.0f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5

         //top edge
         -10.0f, 9.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
         -9.5f, 9.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //6
         -10.0f, 9.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

         -10.0f, 9.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
         -9.5f, 9.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7
         -10.0f, 9.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2

         //left edge
         -9.5f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8
         -10.0f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
         -9.5f, 9.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7

         -9.5f, 9.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7
         -10.0f, 9.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
         -10.0f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4

        //back
        -10.0f, 1.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        -10.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        -10.0f, -0.5f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        -10.0f, -0.5f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        -10.0f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        -10.0f, 1.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1


        //front
        -9.5f, 1.0f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        -9.5f, -0.5f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //6
        -9.5f, -0.5f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7

        -9.5f, -0.5f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7
        -9.5f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8
        -9.5f, 1.0f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5

        //top edge
        -10.0f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        -9.5f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8
        -9.5f, 1.0f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5

        -9.5f, 1.0f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        -10.0f, 1.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        -10.0f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4

        //right edge
        -10.0f, 1.0f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        -9.5f, 1.0f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5
        -10.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2

        -10.0f, -0.5f, -22.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        -9.5f, -0.5f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //6
        -9.5f, 1.0f, -22.0f,        1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //5

        //left edge
        -9.5f, -0.5f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //7
        -10.0f, -0.5f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        -9.5f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8

        -9.5f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //8
        -10.0f, 1.0f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        -10.0f, -0.5f, -7.0f,          1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        //keys for keyboard
        //first row
        4.0f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        5.0f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        5.0f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        5.0f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        4.0f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        4.0f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        4.0f,  -0.275f, -4.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        5.0f,  -0.275f, -4.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        5.0f,  -0.275f, -5.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        5.0f,  -0.275f, -5.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        4.0f,  -0.275f, -5.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        4.0f,  -0.275f, -4.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        4.0f,  -0.275f, -6.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        5.0f,  -0.275f, -6.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        5.0f,  -0.275f, -7.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        5.0f,  -0.275f, -7.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        4.0f,  -0.275f, -7.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        4.0f,  -0.275f, -6.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        4.0f,  -0.275f, -7.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        5.0f,  -0.275f, -7.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        5.0f,  -0.275f, -8.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        5.0f,  -0.275f, -8.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        4.0f,  -0.275f, -8.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        4.0f,  -0.275f, -7.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        4.0f,  -0.275f, -9.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        5.0f,  -0.275f, -9.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        5.0f,  -0.275f, -10.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        5.0f,  -0.275f, -10.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        4.0f,  -0.275f, -10.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        4.0f,  -0.275f, -9.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        4.0f,  -0.275f, -10.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        5.0f,  -0.275f, -10.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        5.0f,  -0.275f, -11.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        5.0f,  -0.275f, -11.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        4.0f,  -0.275f, -11.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        4.0f,  -0.275f, -10.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        4.0f,  -0.275f, -12.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        5.0f,  -0.275f, -12.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        5.0f,  -0.275f, -13.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        5.0f,  -0.275f, -13.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        4.0f,  -0.275f, -13.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        4.0f,  -0.275f, -12.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        4.0f,  -0.275f, -13.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        5.0f,  -0.275f, -13.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        5.0f,  -0.275f, -14.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        5.0f,  -0.275f, -14.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        4.0f,  -0.275f, -14.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        4.0f,  -0.275f, -13.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1



        //Second Row
        5.5f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        6.5f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        6.5f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        6.5f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        5.5f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        5.5f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        5.5f,  -0.275f, -4.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        6.5f,  -0.275f, -4.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        6.5f,  -0.275f, -5.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        6.5f,  -0.275f, -5.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        5.5f,  -0.275f, -5.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        5.5f,  -0.275f, -4.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1


        5.5f,  -0.275f, -6.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        6.5f,  -0.275f, -6.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        6.5f,  -0.275f, -7.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        6.5f,  -0.275f, -7.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        5.5f,  -0.275f, -7.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        5.5f,  -0.275f, -6.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        5.5f,  -0.275f, -7.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        6.5f,  -0.275f, -7.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        6.5f,  -0.275f, -8.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        6.5f,  -0.275f, -8.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        5.5f,  -0.275f, -8.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        5.5f,  -0.275f, -7.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        5.5f,  -0.275f, -9.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        6.5f,  -0.275f, -9.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        6.5f,  -0.275f, -10.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        6.5f,  -0.275f, -10.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        5.5f,  -0.275f, -10.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        5.5f,  -0.275f, -9.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        5.5f,  -0.275f, -10.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        6.5f,  -0.275f, -10.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        6.5f,  -0.275f, -11.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        6.5f,  -0.275f, -11.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        5.5f,  -0.275f, -11.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        5.5f,  -0.275f, -10.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        5.5f,  -0.275f, -12.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        6.5f,  -0.275f, -12.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        6.5f,  -0.275f, -13.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        6.5f,  -0.275f, -13.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        5.5f,  -0.275f, -13.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        5.5f,  -0.275f, -12.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        5.5f,  -0.275f, -13.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        6.5f,  -0.275f, -13.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        6.5f,  -0.275f, -14.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        6.5f,  -0.275f, -14.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        5.5f,  -0.275f, -14.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        5.5f,  -0.275f, -13.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1



        //Third Row
        7.0f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        8.0f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        8.0f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        8.0f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        7.0f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        7.0f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        7.0f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        8.0f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        8.0f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        8.0f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        7.0f,  -0.275f, -4.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        7.0f,  -0.275f, -3.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
            //3
        7.0f,  -0.275f, -4.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        8.0f,  -0.275f, -4.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        8.0f,  -0.275f, -10.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        8.0f,  -0.275f, -10.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        7.0f,  -0.275f, -10.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        7.0f,  -0.275f, -4.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
            //7
        7.0f,  -0.275f, -10.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        8.0f,  -0.275f, -10.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        8.0f,  -0.275f, -11.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        8.0f,  -0.275f, -11.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        7.0f,  -0.275f, -11.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        7.0f,  -0.275f, -10.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        7.0f,  -0.275f, -12.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        8.0f,  -0.275f, -12.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        8.0f,  -0.275f, -13.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        8.0f,  -0.275f, -13.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        7.0f,  -0.275f, -13.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        7.0f,  -0.275f, -12.0f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1

        7.0f,  -0.275f, -13.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1
        8.0f,  -0.275f, -13.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //2
        8.0f,  -0.275f, -14.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3

        8.0f,  -0.275f, -14.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //3
        7.0f,  -0.275f, -14.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //4
        7.0f,  -0.275f, -13.5f,         1.0f, 0.0f,                  0.0f, -1.0f, 0.0f, //1



        //second row


        //third row


        //forth row


    };


    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;
    const GLuint floatsPerNormal = 3;
    // Strides between vertex coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV + floatsPerNormal);

    mesh.nVertices[0] = sizeof(pencilTipVerts) / (sizeof(pencilTipVerts[0]) * (floatsPerVertex + floatsPerUV + floatsPerNormal));
    mesh.nVertices[1] = sizeof(pencilBodyVerts) / (sizeof(pencilBodyVerts[0]) * (floatsPerVertex + floatsPerUV + floatsPerNormal));
    mesh.nVertices[2] = sizeof(pencilEraserVerts) / (sizeof(pencilEraserVerts[0]) * (floatsPerVertex + floatsPerUV + floatsPerNormal));
    mesh.nVertices[3] = sizeof(tableTopVerts) / (sizeof(tableTopVerts[0]) * (floatsPerVertex + floatsPerUV + floatsPerNormal));
    mesh.nVertices[4] = sizeof(keyboardVerts) / (sizeof(keyboardVerts[0]) * (floatsPerVertex + floatsPerUV + floatsPerNormal));
    mesh.nVertices[5] = sizeof(phoneVerts) / (sizeof(phoneVerts[0]) * (floatsPerVertex + floatsPerUV + floatsPerNormal));
    mesh.nVertices[6] = sizeof(screenVerts) / (sizeof(screenVerts[0]) * (floatsPerVertex + floatsPerUV + floatsPerNormal));
    mesh.nVertices[7] = sizeof(phoneEdgeVerts) / (sizeof(phoneEdgeVerts[0]) * (floatsPerVertex + floatsPerUV + floatsPerNormal));
    mesh.nVertices[8] = sizeof(screenEdgeVerts) / (sizeof(screenEdgeVerts[0]) * (floatsPerVertex + floatsPerUV + floatsPerNormal));

#pragma region PencilTipMesh
    glGenVertexArrays(1, &mesh.vao[0]); // we can also generate multiple VAOs or buffers at the same time
    glGenBuffers(1, &mesh.vbo[0]);
    glBindVertexArray(mesh.vao[0]);

    // Create VBO
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(pencilTipVerts), pencilTipVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(2);
#pragma endregion

#pragma region PencilBodyMesh
    glGenVertexArrays(1, &mesh.vao[1]); // we can also generate multiple VAOs or buffers at the same time
    glGenBuffers(1, &mesh.vbo[1]);
    glBindVertexArray(mesh.vao[1]);

    // Create VBO
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[1]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(pencilBodyVerts), pencilBodyVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(2);
#pragma endregion

#pragma region PencilEraserMesh
    glGenVertexArrays(1, &mesh.vao[2]); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao[2]);

    // Create VBO
    glGenBuffers(1, &mesh.vbo[2]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[2]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(pencilEraserVerts), pencilEraserVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(2);
#pragma endregion

#pragma region TableTop
    glGenVertexArrays(1, &mesh.vao[3]); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao[3]);

    // Create VBO
    glGenBuffers(1, &mesh.vbo[3]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[3]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(tableTopVerts), tableTopVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(2);
#pragma endregion

#pragma region KeyboardMesh
    glGenVertexArrays(1, &mesh.vao[4]); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao[4]);

    // Create VBO
    glGenBuffers(1, &mesh.vbo[4]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[4]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(keyboardVerts), keyboardVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(2);
#pragma endregion

#pragma region PhoneMesh
    glGenVertexArrays(1, &mesh.vao[5]); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao[5]);

    // Create VBO
    glGenBuffers(1, &mesh.vbo[5]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[5]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(phoneVerts), phoneVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(2);
#pragma endregion

#pragma region ScreenMesh
    glGenVertexArrays(1, &mesh.vao[6]); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao[6]);

    // Create VBO
    glGenBuffers(1, &mesh.vbo[6]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[6]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(screenVerts), screenVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(2);
#pragma endregion

#pragma region PhoneEdgeMesh
    glGenVertexArrays(1, &mesh.vao[7]); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao[7]);

    // Create VBO
    glGenBuffers(1, &mesh.vbo[7]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[7]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(phoneEdgeVerts), phoneEdgeVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(2);
#pragma endregion

#pragma region ScreenEdgeMesh
    glGenVertexArrays(1, &mesh.vao[8]); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao[8]);

    // Create VBO
    glGenBuffers(1, &mesh.vbo[8]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo[8]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(screenEdgeVerts), screenEdgeVerts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(2);
#pragma endregion

}

void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(4, mesh.vao);
    glDeleteBuffers(4, mesh.vbo);
}

/*Generate and load the texture*/
bool UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (channels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height - 1, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (channels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}



// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
} 


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}